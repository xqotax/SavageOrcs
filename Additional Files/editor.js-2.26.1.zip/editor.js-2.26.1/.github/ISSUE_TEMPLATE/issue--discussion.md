---
name: 'Issue: Discussion'
about: Any question about the project to discuss
title: "❓"
labels: discussion
assignees: ''

---

**Question**

A clear and consistent question about the project. Ex. How can I do smth? Why smth works this way? etc.

**Context**

Why and how the question has come up

**Related issues**

If there are related issues which describe a bugs or features, put them here

**Comments**

Any thoughts about the question
