/**
 * This type of exception will destroy the Editor! Be careful when using it
 */
export class CriticalError extends Error {
}
